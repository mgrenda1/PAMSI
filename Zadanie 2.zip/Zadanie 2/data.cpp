//
// Created by grend on 03.04.2024.
//
#include "vector"
#include "data.h"
#include<iostream>
#include<algorithm>
#include <fstream>
#include <cstdlib>
#include <string>

data::data(){
//    info.emplace_back("ania", 1);
//    info.emplace_back("bartek", 5);
//    info.emplace_back("damian", 2);
//    info.emplace_back("kon", 4);
//    info.emplace_back("kon", 4);
//    info.emplace_back("ania", 1);
//    info.emplace_back("bartek", 5);
//    info.emplace_back("damian", 2);
//    info.emplace_back("kon", 4);
//    info.emplace_back("kon", 4);
}

void data::quick_sort(data &data, int left, int right) {
    if (right <= left)
        return;
    int i = left;
    int j = right;
    int pivot = data.info[(left + right) / 2].second;
    while (i <= j) { // Adjusted the termination condition of the while loop
        while (data.info[i].second > pivot) // Adjusted comparison here
            i++;
        while (data.info[j].second < pivot) // Adjusted comparison here
            j--;
        if (i <= j) {
            data::swap(data, i, j);
            i++;
            j--;
        }
    }
    if (j > left)
        quick_sort(data, left, j);
    if (i < right)
        quick_sort(data, i, right);
}
void data::merge_sort(data &data, int left, int right) {
    int middle = (left + right) / 2;
    if (right > left) {
        merge_sort(data, left, middle);
        merge_sort(data, middle + 1, right);

        std::vector<std::pair<std::string, int>> temp_left(middle - left + 1);
        std::vector<std::pair<std::string, int>> temp_right(right - middle);

        for (int i = 0; i < middle - left + 1; i++) {
            temp_left[i] = data.info[left + i];
        }
        for (int i = 0; i < right - middle; i++) {
            temp_right[i] = data.info[middle + i + 1];
        }

        int i = middle - left, j = right - middle - 1, k = right;
        while (i >= 0 && j >= 0) {
            if (temp_left[i].second <= temp_right[j].second) {
                data.info[k] = temp_left[i];
                i--;
            } else {
                data.info[k] = temp_right[j];
                j--;
            }
            k--;
        }

        while (i >= 0) {
            data.info[k] = temp_left[i];
            i--;
            k--;
        }
        while (j >= 0) {
            data.info[k] = temp_right[j];
            j--;
            k--;
        }
    }
}
int data::max(data &data) {
    int max = data.info[0].second;
    for(auto & i : data.info) {
        if (i.second > max) {
            max = i.second;
        }
    }
    return max;
}
int data::min(data &data) {
    int min = data.info[0].second;
    for(auto & i : data.info) {
        if (i.second < min) {
            min = i.second;
        }
    }
    return min;
}
void data::bucket_sort(data &data) {
    if (data.info.empty())
        return;
    int n = data.info.size();
    int max_val = data.max(data);
    int min_val = data.min(data);
    int num_buckets = max_val - min_val + 1;

    // Create buckets as a vector of vectors
    std::vector<std::vector<std::pair<std::string, int>>> buckets(num_buckets);

    // Distribute elements into buckets
    for (size_t i = 0; i < n; ++i) {
        int bucket_index = data.info[i].second - min_val;
        buckets[bucket_index].push_back(data.info[i]);
    }

    // Temporary object to perform sorting
    class data data_temp;

    int index = 0;
    for (int i = num_buckets - 1; i >= 0; --i) { // Loop in reverse order to sort in descending order
        // Call merge_sort on each bucket
        for (const auto &elem : buckets[i]) {
            data_temp.info.push_back(elem);
        }
        data_temp.merge_sort(data_temp, 0, buckets[i].size() - 1); // Sort bucket in descending order
        for (const auto &elem : buckets[i]) {
            data.info[index++] = elem;
        }
    }
}
void data::swap(data &data ,int i, int j){
    std::pair<std::string,int> temp;
    temp = data.info[i];
    data.info[i] = data.info[j];
    data.info[j] = temp;
}

//void data::load_data(data &data, const std::string& filename, int video_amount, int rate_pos, int shuffle_count, int seed) {
//    int r;
//    std::string line;
//    try {
//        // Open the file for reading
//        std::ifstream file(filename);
//        if (!file.is_open()) {
//            throw std::runtime_error("Error opening file: " + filename);
//        }
//        std::getline(file, line);
//        while (std::getline(file, line) && video_amount > 0) {
//            int dash_count = 0;
//            size_t i = 0;
//            while (i < line.size()) {
//                if (line[i] == '^' && line[line.size()-1] != '^') {
//                    dash_count++;
//                    if (dash_count == rate_pos-1) {
//                        // Prepare title and rating
//                        std::string title = line.substr(0, i);
//                        std::string rating = line.substr(i + 1);
//
//                        r = std::stoi(rating);
//                        info.emplace_back(title, r);
//                        video_amount--;
//                        break; // Exit the loop if rating is found
//                    }
//                }else if(line[i] == '^' && line[line.size()-1] == '^')
//                    break;
//                i++;
//            }
//        }
//
//        if (video_amount > 0) {
//            // Copy remaining elements
//            copy_elements(data, video_amount);
//        }
//    } catch (const std::exception &e) {
//        std::cerr << "Error reading file: " << e.what() << std::endl;
//        return; // Exit the function if there's an error
//    }
//
//    // Shuffle data
//    shuffle_data(data, shuffle_count, seed);
//}
void data::data_out(data &data){
    for (const auto& pair : info) {
        std::cout << pair.first<<std::endl;
    }
}
void data::remove_data(data &data) {
    data.info.clear();
}
void data::shuffle_data(data &data, int shuffle_count, int seed) {
    srand(seed);
    std::pair<std::string, int> info_temp;
    for (int i = 0; i < shuffle_count; i++) {
        for (int j = 0; j < data.info.size(); j++) {
            int size = data.info.size();
            int rand_index = std::rand()%data.info.size();
            std::swap(data.info[j], data.info[rand_index]);
        }
    }
}

void data::copy_elements(data &data, int video_amount) {
    while(video_amount > 0) {
        for (int i = 0; i < info.size(); i++) {
            info.emplace_back(info[i]);
            video_amount--;
            if(video_amount == 0)
                break;
        }
    }
}

void data::load_data_stdin(data &data, int rate_pos) {
    try {
        int r, field = 1, i = 0;
        std::string line;
        int tab_indx[2];
        bool first_dash_found = false;
        bool second_dash_found = false;
        while (std::getline(std::cin, line)) {
            while (i < line.size()) {
                if (line[i] == '^') {
                    field++;
                    if (field == rate_pos && !first_dash_found) {
                        tab_indx[0] = (int) i;
                        first_dash_found = true;
                    }
                    if (field == rate_pos + 1 && !second_dash_found) {
                        tab_indx[1] = (int) i;
                        second_dash_found = true;
                    }
                } else if (field == 1 && rate_pos == 1) {
                    tab_indx[0] = 0;
                    first_dash_found = true;
                }
                i++;
            }
            std::string rating;
            //Prepare title and rating
            if (first_dash_found && second_dash_found) {
                rating = line.substr(tab_indx[0] + 1, tab_indx[1] - tab_indx[0] - 1);
            }
            if (first_dash_found && !second_dash_found) {
                rating = line.substr(tab_indx[0] + 1, line.size() - tab_indx[0]);
            }
            std::cout << rating;
            info.emplace_back(line, std::stoi(rating));
            i = 0;
            first_dash_found = false;
            second_dash_found = false;
        }
    } catch (const std::exception &e) {
        std::cerr << "Error reading line: " << e.what() << std::endl;
        load_data_stdin(data, rate_pos);
    }
}
void data::load_data(data &data, const std::string& filename, int video_amount, int rate_pos, int shuffle_count, int seed) {
    std::string line;
    try {
        // Open the file for reading
        std::ifstream file(filename);
        if (!file.is_open()) {
            throw std::runtime_error("Error opening file: " + filename);
        }
        std::getline(file, line);
        while (std::getline(file, line) && video_amount > 0) {
            std::cout<<line<<std::endl;
            int field = 1;
            int tab_indx[2] ={0};
            bool first_dash_found = false;
            bool second_dash_found = false;
            size_t i = 0;
            while (i < line.size()) {
                if (line[i] == '^') {
                    field++;
                    if (field == rate_pos && !first_dash_found) {
                        tab_indx[0] = (int) i;
                        first_dash_found = true;
                    }
                    if (field == rate_pos + 1 && !second_dash_found) {
                        tab_indx[1] = (int) i;
                        second_dash_found = true;
                    }
                }else if(field == 1 && rate_pos == 1){
                    tab_indx[0] = 0;
                    first_dash_found = true;
                }
                i++;

            }
                 std::string rating;
                        //Prepare title and rating
                        if(first_dash_found && second_dash_found) {
                            rating = line.substr(tab_indx[0], tab_indx[1] - tab_indx[0]);
                        }
                        if(first_dash_found && !second_dash_found) {
                            rating = line.substr(tab_indx[0]+1, line.size() -tab_indx[0]);
                        }
                        info.emplace_back(line, std::stoi(rating));
                        video_amount--;
                        std::cout<<"video"<<video_amount<<std::endl;


        }
        if (video_amount > 0) {
            // Copy remaining elements
            copy_elements(data, video_amount);
        }
    } catch (const std::exception &e) {
        std::cerr << "Error reading file: " << e.what() << std::endl;
        //load_data(data, filename, video_amount, rate_pos, shuffle_count, seed);
        return;
    }

    // Shuffle data
    shuffle_data(data, shuffle_count, seed);



}