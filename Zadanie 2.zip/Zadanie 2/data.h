//
// Created by grend on 03.04.2024.
//

#ifndef ZADANIE_2_DATA_H
#define ZADANIE_2_DATA_H
#include<vector>
#include <iostream>
class data {
public:
    data();
    void quick_sort(data &data, int left, int right);
    void merge_sort(data &data, int left, int right);
    static void bucket_sort(data &data);
    void load_data(data &data, const std::string& filename, int video_amount, int rate_pos , int shuffle_count , int seed);
    void data_out(data &data);
    std::vector<std::pair<std::string, int>> info;
    static void remove_data(data &data);
    void load_data_stdin(data &data, int rate_pos);
private:
    static void swap(data &data ,int i, int j);
    static int max(data &data);
    static int min(data &data);
    void shuffle_data(data &data, int shuffle_count, int seed);
    void copy_elements(data &data, int video_amount);

};



#endif //ZADANIE_2_DATA_H
