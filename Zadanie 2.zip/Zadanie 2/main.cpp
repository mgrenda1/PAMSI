#include <iostream>
#include "data.h"
#include <chrono>
#include <cstdlib>
#include <random>
int main(int argc, char* argv[]) {
    data data;
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_real_distribution<double> dist(1.0, 10.0);
    srand(time(nullptr));
    char algo_letter;
    int shuffle_cycles,seed;
    std::string file_name = argv[1];
    int rate_pos = atoi(argv[2]);
    int video_amount = atoi(argv[3]);
    std::string algo_name = argv[4];
    if(argc == 6){
        shuffle_cycles= atoi(argv[5]);
    }
    if(argc == 7){
        seed = atoi(argv[6]);
    }else{
        seed = dist(mt)*rand();
    }

    if(algo_name == "BUCKET"){
        algo_letter = 'B';
    }else if(algo_name == "QUICK"){
        algo_letter = 'Q';
    }else if(algo_name == "MERGE"){
        algo_letter = 'M';
    }else{
        std::cerr<<"Provided algorithm name is not supported.";
        return -1;
    }
    if(file_name == "-"){

        data.load_data_stdin(data, rate_pos);
    }else{
        data.load_data(data, file_name, video_amount, rate_pos, shuffle_cycles , seed);
        std::cout<<"data done";
    }
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    switch(algo_letter) {
        case 'B':
            data::bucket_sort(data);
        case 'Q':
            data.quick_sort(data, 1, data.info.size() - 1);
        case 'M':
            data.merge_sort(data, 0, data.info.size() - 1);
        default:
            exit;
    }
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    std::cerr<<"Time[sec]: "<<(std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()) /1000000.0  <<std::endl;
    std::cerr<<"Seed: "<<seed<<std::endl;
    data.data_out(data);
    data::remove_data(data);
    return 0;
}



